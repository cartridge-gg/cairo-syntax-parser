use smallvec::SmallVec;
use starknet_types_core::felt::Felt;
use std::borrow::Cow;
use std::fmt::{Display, Result as FmtResult, Write};

pub struct Affixes<'a> {
    prefixes: SmallVec<[Token<'a>; 4]>,
    suffixes: SmallVec<[Token<'a>; 4]>,
}

pub struct CFormat<'a> {
    obj: Box<dyn CWrite + 'a>,
    ops: Affixes<'a>,
}

pub struct CFormatEach<'a, T: CWrite> {
    elements: &'a [T],
    ops: Affixes<'a>,
}

pub struct CDelimited<'a, T: CWrite> {
    elements_writer: CFormatEach<'a, T>,
    delimiter: Option<Token<'a>>,
}

impl CWrite for [u8; 32] {
    fn cwrite(&self, buf: &mut dyn Write) -> FmtResult {
        buf.write_str("0x")?;
        for byte in self.iter() {
            write!(buf, "{:02x}", byte)?;
        }
        Ok(())
    }
}

impl CWrite for [u8; 31] {
    fn cwrite(&self, buf: &mut dyn Write) -> FmtResult {
        buf.write_str("0x00")?;
        for byte in self.iter() {
            write!(buf, "{:02x}", byte)?;
        }
        Ok(())
    }
}

impl CWrite for String {
    fn cwrite(&self, buf: &mut dyn Write) -> FmtResult {
        buf.write_str(self)
    }
}

impl CWrite for &str {
    fn cwrite(&self, buf: &mut dyn Write) -> FmtResult {
        buf.write_str(self)
    }
}

impl CWrite for Felt {
    fn cwrite(&self, buf: &mut dyn Write) -> FmtResult {
        self.to_fixed_hex_string().cwrite(buf)
    }
}

pub trait CWrite {
    fn cwrite(&self, buf: &mut dyn Write) -> FmtResult;
}

pub enum Token<'a> {
    Char(char),
    Str(Cow<'a, str>), // Can be borrowed or owned
}

impl Token<'_> {
    pub fn write_token(&self, buf: &mut dyn Write) -> FmtResult {
        match self {
            Token::Str(s) => buf.write_str(s),
            Token::Char(c) => buf.write_char(*c),
        }
    }
}

impl<'a> From<char> for Token<'a> {
    fn from(c: char) -> Self {
        Token::Char(c)
    }
}

impl<'a> From<&'a str> for Token<'a> {
    fn from(s: &'a str) -> Self {
        Token::Str(Cow::Borrowed(s))
    }
}

impl<'a> From<String> for Token<'a> {
    fn from(s: String) -> Self {
        Token::Str(Cow::Owned(s))
    }
}

pub trait MaybeTokenTrait<'a> {
    fn maybe_token(self) -> Option<Token<'a>>;
}

impl<'a> MaybeTokenTrait<'a> for () {
    fn maybe_token(self) -> Option<Token<'a>> {
        None
    }
}

impl<'a> MaybeTokenTrait<'a> for char {
    fn maybe_token(self) -> Option<Token<'a>> {
        Some(Token::Char(self))
    }
}

impl<'a> MaybeTokenTrait<'a> for &'a str {
    fn maybe_token(self) -> Option<Token<'a>> {
        Some(Token::Str(Cow::Borrowed(self)))
    }
}

impl<'a> MaybeTokenTrait<'a> for String {
    fn maybe_token(self) -> Option<Token<'a>> {
        Some(Token::Str(Cow::Owned(self)))
    }
}

pub trait TokensTrait<'a> {
    fn write_tokens(&self, buf: &mut dyn Write) -> FmtResult;
    fn write_tokens_rev(&self, buf: &mut dyn Write) -> FmtResult;
}

impl TokensTrait<'_> for [Token<'_>] {
    fn write_tokens(&self, buf: &mut dyn Write) -> FmtResult {
        self.iter().try_for_each(|token| token.write_token(buf))
    }
    fn write_tokens_rev(&self, buf: &mut dyn Write) -> FmtResult {
        self.iter()
            .rev()
            .try_for_each(|token| token.write_token(buf))
    }
}

impl Default for Affixes<'_> {
    fn default() -> Self {
        Self::new()
    }
}

impl<'a> CFormat<'a> {
    pub fn new<T: CWrite + 'a>(obj: T) -> Self {
        Self {
            obj: Box::new(obj),
            ops: Affixes::new(),
        }
    }

    pub fn apply(&self, buf: &mut dyn Write) -> FmtResult {
        self.ops.apply_dyn(self.obj.as_ref(), buf)
    }

    pub fn to_string(&self) -> String {
        let mut buf = String::new();
        self.apply(&mut buf).unwrap();
        buf
    }
}

impl CWrite for CFormat<'_> {
    fn cwrite(&self, buf: &mut dyn Write) -> FmtResult {
        self.apply(buf)
    }
}

impl Display for CFormat<'_> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> FmtResult {
        self.apply(f)
    }
}

impl<'a> AppendWriteOps<'a> for CFormat<'a> {
    fn prefix_token(&mut self, val: Token<'a>) {
        self.ops.prefix_token(val);
    }
    fn suffix_token(&mut self, val: Token<'a>) {
        self.ops.suffix_token(val);
    }
}

impl<'a, T: CWrite> CFormatEach<'a, T> {
    pub fn new(elements: &'a [T], ops: Affixes<'a>) -> Self {
        Self { elements, ops }
    }

    pub fn new_empty(elements: &'a [T]) -> Self {
        Self {
            elements,
            ops: Affixes::new(),
        }
    }

    pub fn apply(&self, buf: &mut dyn Write) -> FmtResult {
        self.ops.apply_prefixes(buf)?;
        for elem in self.elements.iter() {
            elem.cwrite(buf)?;
        }
        self.ops.apply_suffixes(buf)
    }

    pub fn join<D: MaybeTokenTrait<'a>>(self, delimiter: D) -> CDelimited<'a, T> {
        CDelimited {
            elements_writer: self,
            delimiter: delimiter.maybe_token(),
        }
    }

    pub fn tuple(self) -> CDelimited<'a, T> {
        let mut slice_writer = self.join(", ");
        slice_writer.elements_writer.ops.enclose('(');
        slice_writer
    }

    pub fn array(self) -> CDelimited<'a, T> {
        let mut slice_writer = self.join(", ");
        slice_writer.elements_writer.ops.enclose('[');
        slice_writer
    }

    pub fn block(self) -> CDelimited<'a, T> {
        let mut slice_writer = self.join(", ");
        slice_writer.elements_writer.ops.enclose('{');
        slice_writer
    }

    pub fn comma_separated(self) -> CDelimited<'a, T> {
        self.join(", ")
    }

    pub fn space_separated(self) -> CDelimited<'a, T> {
        self.join(' ')
    }

    pub fn to_string(&self) -> String {
        let mut buf = String::new();
        self.apply(&mut buf).unwrap();
        buf
    }
}

impl<'a, T: CWrite> AppendWriteOps<'a> for CFormatEach<'a, T> {
    fn prefix_token(&mut self, val: Token<'a>) {
        self.ops.prefix_token(val);
    }
    fn suffix_token(&mut self, val: Token<'a>) {
        self.ops.suffix_token(val);
    }
}

impl<'a, T: CWrite> CDelimited<'a, T> {
    pub fn new(elements: &'a [T], element_ops: Affixes<'a>, delimiter: Option<Token<'a>>) -> Self {
        Self {
            elements_writer: CFormatEach::new(elements, element_ops),
            delimiter,
        }
    }

    pub fn apply(&self, buf: &mut dyn Write) -> FmtResult {
        self.elements_writer.ops.apply_prefixes(buf)?;
        let mut iter = self.elements_writer.elements.iter();
        if let Some(first) = iter.next() {
            first.cwrite(buf)?;
            for elem in iter {
                if let Some(delim) = &self.delimiter {
                    delim.write_token(buf)?;
                }
                elem.cwrite(buf)?;
            }
        }
        self.elements_writer.ops.apply_suffixes(buf)
    }

    pub fn to_string(&self) -> String {
        let mut buf = String::new();
        self.apply(&mut buf).unwrap();
        buf
    }
}

impl<T: CWrite> CWrite for CDelimited<'_, T> {
    fn cwrite(&self, buf: &mut dyn Write) -> FmtResult {
        self.apply(buf)
    }
}

impl<T: CWrite> Display for CDelimited<'_, T> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> FmtResult {
        self.apply(f)
    }
}

impl<'a, T: CWrite> AppendWriteOps<'a> for CDelimited<'a, T> {
    fn prefix_token(&mut self, val: Token<'a>) {
        self.elements_writer.ops.prefix_token(val);
    }
    fn suffix_token(&mut self, val: Token<'a>) {
        self.elements_writer.ops.suffix_token(val);
    }
}

impl<'a> Affixes<'a> {
    pub fn new() -> Self {
        Self {
            prefixes: Default::default(),
            suffixes: Default::default(),
        }
    }

    pub fn apply_prefixes(&self, buf: &mut dyn Write) -> FmtResult {
        self.prefixes.write_tokens_rev(buf)
    }
    pub fn apply_suffixes(&self, buf: &mut dyn Write) -> FmtResult {
        self.suffixes.write_tokens(buf)
    }

    pub fn apply<T: CWrite + ?Sized, W: Write>(&self, obj: &T, buf: &mut W) -> FmtResult {
        self.apply_prefixes(buf)?;
        obj.cwrite(buf)?;
        self.apply_suffixes(buf)
    }

    pub fn apply_dyn(&self, obj: &dyn CWrite, buf: &mut dyn Write) -> FmtResult {
        self.apply_prefixes(buf)?;
        obj.cwrite(buf)?;
        self.apply_suffixes(buf)
    }
}

pub trait AppendWriteOps<'a>: Sized {
    fn prefix_token(&mut self, val: Token<'a>);
    fn suffix_token(&mut self, val: Token<'a>);
    fn prefix<T: Into<Token<'a>>>(&mut self, val: T) {
        self.prefix_token(val.into());
    }
    fn suffix<T: Into<Token<'a>>>(&mut self, val: T) {
        self.suffix_token(val.into());
    }
    fn wrap<T: Into<Token<'a>>, U: Into<Token<'a>>>(&mut self, prefix: T, suffix: U) {
        self.prefix(prefix);
        self.suffix(suffix);
    }
    fn enclose(&mut self, val: char) {
        let (open, close) = get_enclosers(val);
        self.wrap(open, close);
    }
    fn prefixed<T: Into<Token<'a>>>(mut self, val: T) -> Self {
        self.prefix(val);
        self
    }
    fn suffixed<T: Into<Token<'a>>>(mut self, val: T) -> Self {
        self.suffix(val);
        self
    }
    fn wrapped<T: Into<Token<'a>>, U: Into<Token<'a>>>(mut self, prefix: T, suffix: U) -> Self {
        self.wrap(prefix, suffix);
        self
    }
    fn enclosed(mut self, val: char) -> Self {
        self.enclose(val);
        self
    }
}

impl<'a> AppendWriteOps<'a> for Affixes<'a> {
    fn prefix_token(&mut self, val: Token<'a>) {
        self.prefixes.push(val);
    }
    fn suffix_token(&mut self, val: Token<'a>) {
        self.suffixes.push(val);
    }
}

pub fn get_enclosers(c: char) -> (char, char) {
    match c {
        '(' => ('(', ')'),
        '{' => ('{', '}'),
        '[' => ('[', ']'),
        '<' => ('<', '>'),
        _ => (c, c),
    }
}

impl<T: CWrite> CWrite for CFormatEach<'_, T> {
    fn cwrite(&self, buf: &mut dyn Write) -> FmtResult {
        self.apply(buf)
    }
}

impl<T: CWrite> Display for CFormatEach<'_, T> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> FmtResult {
        self.apply(f)
    }
}
